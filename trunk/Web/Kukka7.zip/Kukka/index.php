<!DOCTYPE html>
<head>
  <!-- Titre de la page -->
  <title>Menu</title>
  <!-- Format caratère -->
  <meta charset="utf-8">
  <meta name="format-detection" content="telephone=no">
  <!-- Fiches de style -->
  <link rel="stylesheet" href="css/stuck.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/ihover.css">
  <!-- Inclusion du jquery -->
  <script src="js/jquery.js"></script>
  <script src="js/jquery-migrate-1.1.1.js"></script>
  <script src="js/script.js"></script>
  <script src="js/superfish.js"></script>
  <script src="js/jquery.equalheights.js"></script>
  <script src="js/jquery.mobilemenu.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/tmStickUp.js"></script>
  <script src="js/jquery.ui.totop.js"></script>
  <script>
   $(document).ready(function()
   {
      $().UItoTop({ easingType: 'easeOutQuart' });
      $('#stuck_container').tmStickUp({});
   });
  </script>
</head>
<body class="page1" id="top">
  <!--==============================
                header
  =================================-->
  <?php include("header.php"); ?>
  <!--=====================
            Content
  ======================-->
  <section class="content">
    <div class="container">
      <div class="row">
        <div class="grid_12">
          <div class="ta__center">
            <!-- Insertion des quatres bannières symbolisant un menu visuel supplémentaire au menu principal du header -->
            <div class="banners">
              <a href="svg.php" class="banner">
                <img src="images/bann_svg.png" alt="">
                <div class="bann_capt"><span>SVG Image</span></div>
              </a>
              <a href="cdc.php" class="banner">
                <img src="images/bann_cdc.jpg" alt="">
                <div class="bann_capt"><span>Chaîne de caractère</span></div>
              </a>
              <a href="webcam.php" class="banner">
                <img src="images/bann_webcam.png" alt="">
                <div class="bann_capt"><span>Webcam</span></div>
              </a>
              <a href="dessin.php" class="banner">
                <img src="images/bann_dessin.jpg" alt="">
                <div class="bann_capt"><span>Dessin</span></div>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--==============================
                Footer
  =================================-->
  <?php include("footer.php"); ?>
</body>
</html>