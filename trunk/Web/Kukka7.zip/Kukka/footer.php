<!--==============================
              footer
=================================-->
<footer id="footer">
  <div class="container">
    <div class="row">
      <div class="grid_12">
        <div class="copyright">
          <!-- Ajout des éléments du footer -->
          <!-- Première ligne -->
        	<span class="brand">IMERIR</span> &copy; 
          <!-- Deuxième ligne -->
        	<div> Matthieu MENAGE, Brice BENOIT, Jérémy JOUET, Dorian FERNANDEZ, Remi GANDOU et Guillaum PEREZ </div>
        </div>
      </div>
    </div>
  </div>
</footer>