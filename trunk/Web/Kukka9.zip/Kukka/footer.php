<!--==============================
              footer
=================================-->
<footer id="footer">
  <div class="container">
    <div class="row">
      <div class="grid_12">
        <div class="copyright">
        	<span class="brand">IMERIR</span> &copy; 
        	<div> Matthieu MENAGE, Brice BENOIT, Jérémy JOUET, Dorian FERNANDEZ, Remi GANDOU et Guillaum PEREZ </div>
        </div>
      </div>
    </div>
  </div>
</footer>