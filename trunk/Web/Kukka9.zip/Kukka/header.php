<!--==============================
              header
=================================-->
<header>
<!--==============================
            Stuck menu
=================================-->
  <section id="stuck_container">
    <div class="container">
      <div class="row">
        <div class="grid_12">
        <h1>
          <a href="index.php">
            <img src="images/logo_header.jpg" alt="Logo alt">
          </a>
        </h1>
          <div class="navigation ">
            <nav>
              <ul class="sf-menu">
               <li class="current"><a href="index.php">Accueil</a></li>
               <li><a href="svg.php">SVG images</a></li>
               <li><a href="cdc.php">Chaîne</a></li>
               <li><a href="webcam.php">Webcam</a></li>
               <li><a href="dessin.php">Dessins</a></li>
             </ul>
            </nav>
            <div class="clear"></div>
          </div>
        </div>
      </div>
    </div>
  </section>
</header>